<?php

namespace Shasoft\CacheInvalidation;

use Shasoft\CacheInvalidation\CacheInvalidationInterface;

class CacheInvalidationManager
{
    // Установить параметры
    static public function setConfig(CacheInvalidationInterface $cache): void
    {
        $refClass = new \ReflectionClass(CacheInvalidationItem::class);
        $refProperty = $refClass->getProperty('cache');
        $refProperty->setAccessible(true);
        $refProperty->setValue($cache);
    }
    // Получить значение ключа
    static public function key(string $classname, ...$argsKey): string
    {
        $tmp = explode("\\", $classname);
        return array_pop($tmp) . ':' . $argsKey[0];
        //return md5($classname . ':' . serialize($argsKey));
    }
};
