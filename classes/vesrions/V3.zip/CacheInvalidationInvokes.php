<?php

namespace Shasoft\CacheInvalidation;

class CacheInvalidationInvokes
{
    // Конструктор
    public function __construct(
        protected array $multiArgs,
        protected array $argNames,
        protected array &$results
    ) {
    }
    // Установить значение
    public function setResult(int $index, mixed $value): void
    {
        $this->results[$index] = $value;
    }
    // Перебрать все значения
    public function each(callable $cb): void
    {
        foreach ($this->multiArgs as $args) {
            $values = [];
            foreach ($this->argNames as $name) {
                $values[] = $args[$name];
            }
            call_user_func_array($cb, $values);
        }
    }
};
