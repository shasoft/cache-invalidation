<?php

namespace Shasoft\CacheInvalidation;

use Psr\Cache\CacheItemPoolInterface;

class CacheInvalidationManager
{
    // Интерфейс работы с КЭШем
    static protected ?CacheItemPoolInterface $cache = null;
    // Установить параметры
    static public function setConfig(CacheItemPoolInterface $cache): void
    {
        self::$cache = $cache;
    }
    // Получить значение ключа
    static public function key(string $classname, ...$argsKey): string
    {
        return md5($classname . ':' . serialize($argsKey));
    }
    // Получить значение
    static public  function get(string $classname, ...$argsKey): mixed
    {
        // Получить элемент КЭШа
        $itemCache = self::$cache->getItem(self::key($classname, ...$argsKey));
        // Если в КЭШе есть значение
        if ($itemCache->isHit()) {
            // то вернуть значение
            return $itemCache->get();
        }
        // Создать объект для работы с элементом КЭШа
        $objectCache = new $classname(...$argsKey);
        // Вызвать метод чтения значения
        $ret = $objectCache->read();
        // Сохранить значение в КЭШ
        $itemCache->set($ret);
        self::$cache->save($itemCache);
        // Вернуть значение
        return $ret;
    }
    // Установить значение
    static public  function set(string $classname, ...$args): void
    {
        // Рефлексия класса
        $refClass = new \ReflectionClass($classname);
        // Рефлексия конструктора
        $refConstructor = $refClass->getConstructor();
        // Определить количество параметров ключа
        $sizeKey = $refConstructor ? $refConstructor->getNumberOfParameters() : 0;
        // Определить параметры ключа
        $argsKey = array_slice($args, 0, $sizeKey);
        // Создать объект для работы с элементом КЭШа
        $objectCache = new $classname(...$argsKey);
        // Вызвать метод изменения значения (если он есть)
        if ($refClass->hasMethod('write')) {
            $objectCache->write(...array_slice($args, $sizeKey));
        }
        // Получить элемент КЭШа
        $itemCache = self::$cache->getItem(self::key($classname, ...$argsKey));
        // Если в КЭШе есть значение
        if ($itemCache->isHit()) {
            // то изменить значение в КЭШе
            $itemCache->set($objectCache->read());
            self::$cache->save($itemCache);
        }
    }
};
