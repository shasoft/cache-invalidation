<?php

namespace Shasoft\CacheInvalidation;

use Shasoft\CacheInvalidation\CacheInvalidationInterface;

class CacheInvalidationItem
{
    // Интерфейс работы с КЭШем
    static protected ?CacheInvalidationInterface $cache = null;
    // Очередь ключей генерируемых элементов КЭШа
    static protected array $queueKeys = [];
    // Получить значение
    static public function get(...$argsKey): mixed
    {
        return s_log(function () use ($argsKey) {
            // Родительский ключ
            $parentKey = empty(self::$queueKeys) ? null : self::$queueKeys[array_key_last(self::$queueKeys)];
            // Сгенерировать ключ
            $key = CacheInvalidationManager::key(static::class, ...$argsKey);
            // Вернуть значение
            return self::$cache->get(
                $key,
                $parentKey,
                function () use ($argsKey, $key) {
                    // Создать объект для работы с элементом КЭШа
                    $objectCache = new static(...$argsKey);
                    // Добавить текущий ключ в очередь
                    self::$queueKeys[] = $key;
                    // Вызвать метод чтения значения
                    $ret = call_user_func([$objectCache, 'read']);
                    // Удалить текущий ключ из очереди
                    array_pop(self::$queueKeys);
                    // Вернуть значение
                    return $ret;
                }
            );
        });
    }
    // Установить значение
    static public function set(...$args): void
    {
        s_log(function () use ($args) {
            // Рефлексия класса
            $refClass = new \ReflectionClass(static::class);
            // Рефлексия конструктора
            $refConstructor = $refClass->getConstructor();
            // Определить количество параметров ключа
            $sizeKey = $refConstructor ? $refConstructor->getNumberOfParameters() : 0;
            // Определить параметры ключа
            $argsKey = array_slice($args, 0, $sizeKey);
            // Создать объект для работы с элементом КЭШа
            $objectCache = new static(...$argsKey);
            // Вызвать метод изменения значения (если он есть)
            if ($refClass->hasMethod('write')) {
                call_user_func_array([$objectCache, 'write'], array_slice($args, $sizeKey));
            }
            // Изменить значение
            self::$cache->set(
                CacheInvalidationManager::key(static::class, ...$argsKey),
                function () use ($objectCache) {
                    return call_user_func([$objectCache, 'read']);
                }
            );
        });
    }
};
