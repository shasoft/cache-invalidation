<?php

namespace Shasoft\CacheInvalidation;

use Psr\Cache\CacheItemInterface;

interface CacheInvalidationInterface
{
    /**
     * Получить значение по ключу для родительского элемента
     * @param string $key
     *   Ключ запрашиваемого элемента
     * @param ?string $parentKey
     *   Ключ родительского элемента запрашиваемого элемента (null если родителя нет)
     * @param \Closure $value
     *   Замыкание, возвращающее значение
     *
     * @return mixed
     *   Значение.
     */
    public function get(string $key, ?string $parentKey, \Closure $value): mixed;
    /**
     * Изменить значение
     * @param string $key
     *   Ключ изменяемого элемента
     * @param \Closure $value
     *   Замыкание, возвращающее значение
     *
     * @return bool
     *   Значение True, если элемент был успешно сохранен. Значение False, если произошла ошибка.
     */
    public function set(string $key, \Closure $value): bool;
};
