<?php

namespace Shasoft\CacheInvalidation;

interface CacheLinksInterface
{
    // Добавить связь
    public function addLink(string $key, string $parentKey): void;
    // Получить всех родителей
    public function getParents(array $keys): array;
    // Удалить все дочерние связи
    public function clearChildren(string $parentKey): void;
};
