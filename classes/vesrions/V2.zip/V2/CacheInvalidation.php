<?php

namespace Shasoft\CacheInvalidation;

use Psr\Cache\CacheItemPoolInterface;
use Shasoft\CacheInvalidation\CacheLinksInterface;

class CacheInvalidation implements CacheInvalidationInterface
{
    // Конструктор
    public function __construct(
        protected CacheItemPoolInterface $cacheItemPool,
        protected CacheLinksInterface $cacheLinks
    ) {
    }
    // Получить значение по ключу для родительского элемента
    public function get(string $key, ?string $parentKey, \Closure $value): mixed
    {
        return s_log(function () use ($key, $parentKey, $value) {

            // Получить элемент КЭШа
            $itemCache = $this->cacheItemPool->getItem($key);
            // Если в КЭШе есть значение
            if ($itemCache->isHit()) {
                // Добавить родителя для текущего элемента КЭШа (если родитель есть)
                $this->cacheLinks->addLink($key, $parentKey);
                // то вернуть значение
                return $itemCache->get();
            }
            // Удалить все дочерние связи
            $this->cacheLinks->clearChildren($key);
            // Добавить родителя для текущего элемента КЭШа (если родитель есть)
            $this->cacheLinks->addLink($key, $parentKey);
            // Получить значение
            $ret = $value($key);
            // Изменить значение в КЭШе
            $itemCache->set($ret);
            $this->cacheItemPool->save($itemCache);
            // Вернуть значение
            return $ret;
        });
    }
    // Установить значение
    public function set(string $key, \Closure $value): bool
    {
        return s_log(function () use ($key, $value) {
            $ret = true;
            // Получить элемент КЭШа
            $itemCache = $this->cacheItemPool->getItem($key, null);
            // Если в КЭШе есть значение 
            if ($itemCache->isHit()) { // ???!!! Возможно эта проверка не нужна? !!!???
                // то изменить значение в КЭШе
                $itemCache->set($value());
                $this->cacheItemPool->save($itemCache);
            }

            // Если в КЭШе есть значение
            if ($itemCache->isHit()) {
                // то изменить значение в КЭШе
                $ret &= $this->cacheItemPool->save($itemCache);
            }
            // Удалить все родительские значения в КЭШе
            $keys = [$key];
            while (true) {
                $keys = $this->cacheLinks->getParents($keys);
                if (empty($keys)) {
                    break;
                }
                $this->cacheItemPool->deleteItems($keys);
            }
            // вернуть результат работы
            return $ret;
        });
    }
};
