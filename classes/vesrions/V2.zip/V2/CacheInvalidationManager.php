<?php

namespace Shasoft\CacheInvalidation;

use Shasoft\CacheInvalidation\CacheInvalidationInterface;

class CacheInvalidationManager
{
    // Интерфейс работы с КЭШем
    static protected ?CacheInvalidationInterface $cache = null;
    // Очередь ключей генерируемых элементов КЭШа
    static protected array $queueKeys = [];
    // Установить параметры
    static public function setConfig(CacheInvalidationInterface $cache): void
    {
        self::$cache = $cache;
    }
    // Получить значение ключа
    static public function key(string $classname, ...$argsKey): string
    {
        $tmp = explode("\\", $classname);
        return array_pop($tmp) . ':' . $argsKey[0];
        //return md5($classname . ':' . serialize($argsKey));
    }
    // Получить значение
    static public  function get(string $classname, ...$argsKey): mixed
    {
        return s_log(function () use ($classname, $argsKey) {
            // Родительский ключ
            $parentKey = empty(self::$queueKeys) ? null : self::$queueKeys[array_key_last(self::$queueKeys)];
            // Сгенерировать ключ
            $key = self::key($classname, ...$argsKey);
            // Вернуть значение
            return self::$cache->get(
                $key,
                $parentKey,
                function () use ($classname, $argsKey, $key) {
                    // Создать объект для работы с элементом КЭШа
                    $objectCache = new $classname(...$argsKey);
                    // Добавить текущий ключ в очередь
                    self::$queueKeys[] = $key;
                    // Вызвать метод чтения значения
                    $ret = $objectCache->read();
                    // Удалить текущий ключ из очереди
                    array_pop(self::$queueKeys);
                    // Вернуть значение
                    return $ret;
                }
            );
        });
    }
    // Установить значение
    static public  function set(string $classname, ...$args): void
    {
        s_log(function () use ($classname, $args) {
            // Рефлексия класса
            $refClass = new \ReflectionClass($classname);
            // Рефлексия конструктора
            $refConstructor = $refClass->getConstructor();
            // Определить количество параметров ключа
            $sizeKey = $refConstructor ? $refConstructor->getNumberOfParameters() : 0;
            // Определить параметры ключа
            $argsKey = array_slice($args, 0, $sizeKey);
            // Создать объект для работы с элементом КЭШа
            $objectCache = new $classname(...$argsKey);
            // Вызвать метод изменения значения (если он есть)
            if ($refClass->hasMethod('write')) {
                $objectCache->write(...array_slice($args, $sizeKey));
            }
            // Изменить значение
            self::$cache->set(
                self::key($classname, ...$argsKey),
                function () use ($objectCache) {
                    return $objectCache->read();
                }
            );
        });
    }
};
