<?php

namespace Shasoft\CacheInvalidation;

use Psr\Cache\CacheItemPoolInterface;

class CacheLinksArray implements CacheLinksInterface
{
    protected array $storage = [];
    //
    private static string $PARENT = 'P';
    private static string $CHILDREN = 'C';
    // Конструктор
    public function __construct(
        protected CacheItemPoolInterface $cacheItemPool
    ) {
    }
    // Получить ключ наличия связи
    private function getLinkKey(string $key, string $parentKey): string
    {
        return $key . '.' . $parentKey;
    }
    // Добавить связь
    public function addLink(string $key, ?string $parentKey): void
    {
        s_log(function () use ($key, $parentKey) {
            if ($parentKey) {
                // Проверить наличие родителя
                $itemCacheParent = $this->cacheItemPool->getItem($this->getLinkKey($key, $parentKey));
                // Если родителя нет
                //if (!$itemCacheParent->isHit()) 
                {
                    // то установить флаг наличия родителя
                    $itemCacheParent->set(1);
                    $this->cacheItemPool->save($itemCacheParent);
                    // Добавить родителя
                    if (!array_key_exists($key, $this->storage)) {
                        $this->storage[$key] = [
                            self::$PARENT => [],   // Родительские ключи
                            self::$CHILDREN => []  // Дочерние ключи
                        ];
                    }
                    $this->storage[$key][self::$PARENT][$parentKey] = 1;
                    // Добавить дочерние ключи
                    if (!array_key_exists($parentKey, $this->storage)) {
                        $this->storage[$parentKey] = [
                            self::$PARENT => [],   // Родительские ключи
                            self::$CHILDREN => []  // Дочерние ключи
                        ];
                    }
                    $this->storage[$parentKey][self::$CHILDREN][$key] = 1;
                }
            }
        });
    }
    // Получить всех родителей
    public function getParents(array $keys): array
    {
        return s_log(function () use ($keys) {
            $ret = [];
            foreach ($keys as $key) {
                if (array_key_exists($key, $this->storage)) {
                    // Получить список родителей
                    $ret = array_merge($ret, array_keys($this->storage[$key][self::$PARENT]));
                }
            }
            // Вернуть
            return $ret;
        });
    }
    // Удалить все дочерние связи
    public function clearChildren(string $parentKey): void
    {
        s_log(function () use ($parentKey) {
            if (array_key_exists($parentKey, $this->storage)) {
                //
                $linkKeys = [];
                // Удалить ссылки в дочках на данный родительский элемент
                foreach (array_keys($this->storage[$parentKey][self::$CHILDREN]) as $key) {
                    $linkKeys[] = $this->getLinkKey($key, $parentKey);
                    if (array_key_exists($key, $this->storage)) {
                        unset($this->storage[$parentKey][self::$PARENT][$key]);
                    }
                }
                // Удалить дочерние ключи
                $this->storage[$parentKey][self::$CHILDREN] = [];
                // Удалить флаги
                $this->cacheItemPool->deleteItems($linkKeys);
            }
        });
    }
    // Все значения
    public function all(): array
    {
        return $this->storage;
    }
};
